import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class Empresa extends JFrame {

    //Variable para ir mostrando a los empleados
    int indice = 0;

    //Etiquetas para identificar los campos de texto
    private JLabel nombreLabel;
    private JLabel fechaLabel;
    private JLabel salarioLabel;

    //Cadenas para las etiquetas
    private static String nombreString = "Nombre: ";
    private static String fechaString = "Fecha Nacimiento: ";
    private static String salarioString = "Salario: ";

    //Text fields para introducir números
    private TextField nombreField;
    private TextField fechaField;
    private TextField salarioField;


    private boolean focusIsSet = false;

    public Empresa() {
        super("Empresa");

        //Creamos la lista de empleados
        List<Empleado> empleados = new ArrayList<>();


        //Crea los 5 empleados
        empleados.add(new Empleado("Juan Pérez", "22/03/1992", 3000.00));
        empleados.add(new Empleado("Ana Gómez", "22/08/1999", 3200.00));
        empleados.add(new Empleado("Carlos Martínez", "12/06/1982", 3500.00));
        empleados.add(new Empleado("Laura Fernández", "04/03/1986", 3100.00));
        empleados.add(new Empleado("Pedro López", "09/10/1993", 2900.00));


        //Crea las etiquetas.
        nombreLabel = new JLabel(nombreString);
        fechaLabel = new JLabel(fechaString);
        salarioLabel = new JLabel(salarioString);

        //Campo donde nos muestra el nombre
        nombreField = new TextField(10);
        nombreField.setEditable(false);


        //Campo que nos muestra la fecha
        fechaField = new TextField(10);
        fechaField.setEditable(false);

        //Campo que nos muestra el salario
        salarioField = new TextField(10);
        salarioField.setEditable(false);


        //Primera muestra al iniciar el programa
        nombreField.setText(empleados.get(indice).getNombre());
        fechaField.setText(empleados.get(indice).getFechaNacimiento());
        salarioField.setText(" "+empleados.get(indice).getSalario());




        //Declaramos los botones
        JButton buttonNext = new JButton("=>");
        JButton buttonBefore = new JButton("<=");
        JButton buttonStart = new JButton("Inicio");
        JButton buttonEnd = new JButton("Final");

        //Que empiecen desabilitados los botones inicio y hacia atras
        buttonStart.setEnabled(false);
        buttonBefore.setEnabled(false);


        //Al pulsar el boton de anterior
        buttonBefore.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (buttonBefore.getText().equals("<=")) {
                    buttonEnd.setEnabled(true);
                    buttonStart.setEnabled(true);
                    if (indice == 1) {
                        buttonBefore.setEnabled(false);
                        buttonStart.setEnabled(false);
                    }
                    buttonNext.setEnabled(true);
                    if (indice > 0) {
                        indice--;
                        nombreField.setText(empleados.get(indice).getNombre());
                        fechaField.setText(empleados.get(indice).getFechaNacimiento());
                        salarioField.setText(" " + empleados.get(indice).getSalario());
                    }
                }
            }

        });

        //Al pulsar boton siguiente
        buttonNext.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (buttonNext.getText().equals("=>")) {
                    buttonStart.setEnabled(true);
                    buttonBefore.setEnabled(true);
                    buttonEnd.setEnabled(true);
                    if (indice == empleados.size() - 1) {
                        altaEmpleado(buttonStart, buttonBefore, buttonEnd, buttonNext, nombreField, fechaField, salarioField, empleados);
                    }
                    if (indice == empleados.size() - 2) {
                        buttonEnd.setEnabled(false);
                    }
                    if (indice < empleados.size() - 1) {
                        indice++;
                        nombreField.setText(empleados.get(indice).getNombre());
                        fechaField.setText(empleados.get(indice).getFechaNacimiento());
                        salarioField.setText(" " + empleados.get(indice).getSalario());
                    }
                }
            }
        });

        //Al pulsar boton inicio
        buttonStart.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                buttonEnd.setEnabled(true);
                buttonStart.setEnabled(false);
                buttonBefore.setEnabled(false);
                buttonNext.setEnabled(true);
                indice = 0;
                nombreField.setText(empleados.get(indice).getNombre());
                fechaField.setText(empleados.get(indice).getFechaNacimiento());
                salarioField.setText(" "+empleados.get(indice).getSalario());

            }

        });

        //Al pulsar boton final
        buttonEnd.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                buttonEnd.setEnabled(false);
                buttonStart.setEnabled(true);
                buttonBefore.setEnabled(true);
                if(indice < empleados.size()){
                    indice = empleados.size() - 1;
                    nombreField.setText(empleados.get(indice).getNombre());
                    fechaField.setText(empleados.get(indice).getFechaNacimiento());
                    salarioField.setText(" "+empleados.get(indice).getSalario());

                }
            }

        });


        //Dispone la geometría de las etiquetas en un panel
        JPanel labelPane = new JPanel();
        labelPane.setLayout(new GridLayout(0, 1));
        labelPane.add(nombreLabel);
        labelPane.add(fechaLabel);
        labelPane.add(salarioLabel);


        //Dispone los campos de texto en otro panel
        JPanel fieldPane = new JPanel();
        fieldPane.setLayout(new GridLayout(0, 1));
        fieldPane.add(nombreField);
        fieldPane.add(fechaField);
        fieldPane.add(salarioField);

        //Agregamos los botones al panel
        JPanel buttonPane = new JPanel();
        buttonPane.add(buttonStart);
        buttonPane.add(buttonBefore);
        buttonPane.add(buttonNext);
        buttonPane.add(buttonEnd);



        //Incluye los dos paneles en otro panel,
        //etiquetas a la izquierda
        //y campos de texto a la derecha.
        JPanel contentPane = new JPanel();
        contentPane.setBorder(
                BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPane.setLayout(new BorderLayout());
        contentPane.add(labelPane, BorderLayout.CENTER);
        contentPane.add(fieldPane, BorderLayout.EAST);
        contentPane.add(buttonPane, BorderLayout.SOUTH);

        setContentPane(contentPane);  //this.setContentPane(contentPane);
        // es set, o sea, machado el contenedor del objeto "Doble", hijo de JFrame

    }

    private void altaEmpleado(JButton buttonStart, JButton buttonBefore, JButton buttonEnd, JButton buttonNext, TextField nombreField, TextField fechaField, TextField salarioField, List<Empleado> empleados) {
        nombreField.setText(" ");
        fechaField.setText(" ");
        salarioField.setText(" ");
        nombreField.setEditable(true);
        fechaField.setEditable(true);
        salarioField.setEditable(true);

        buttonNext.setText("Alta");
        buttonBefore.setText("Cancelar");
        buttonStart.setEnabled(false);


        buttonBefore.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(buttonBefore.getText().equals("Cancelar")) {
                    botones(buttonNext, buttonBefore, buttonStart);
                    return;
                }
            }
        });




        buttonNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(buttonNext.getText().equals("Alta")) {
                    String nombre = nombreField.getText();
                    String fecha = fechaField.getText();
                    String salarioF = salarioField.getText();


                    if(!nombre.equals(" ") && !fecha.equals(" ") && !salarioF.equals(" ")){
                        double salario = Double.parseDouble(salarioF);
                        Empleado empleado = new Empleado(nombre, fecha, salario);
                        empleados.add(empleado);
                        botones(buttonNext, buttonBefore, buttonStart);
                        return;
                    }
                    else{
                        System.out.println("Has dejado algun campo en blanco");
                    }
                }
            }

        });


    }

    private void botones(JButton buttonNext, JButton buttonBefore, JButton buttonStart) {
        buttonNext.setText("=>");
        buttonBefore.setText("<=");
        Empresa.this.nombreField.setEditable(false);
        Empresa.this.fechaField.setEditable(false);
        Empresa.this.salarioField.setEditable(false);
        buttonStart.setEnabled(true);
    }


    public void setFocus() {
        if (!focusIsSet) {
            focusIsSet = true;
        }
    }
}

